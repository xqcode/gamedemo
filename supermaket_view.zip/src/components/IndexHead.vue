<template>
	<div style="margin:0;padding:0;background-color:#f0f8ff;width:100%;height: 25px;">
		<el-row type="flex" class="row-bg" justify="center">
			<el-col :span="6">
				<el-dropdown   size="small">
					<span class="el-dropdown-link">
						<font size="1">中国大陆</font><i class="el-icon-arrow-down el-icon--right"></i>
					</span>
					<el-dropdown-menu slot="dropdown">
						<el-dropdown-item><font size="1">上海</font></el-dropdown-item>
						<el-dropdown-item><font size="1">北京</font></el-dropdown-item>
						<el-dropdown-item><font size="1">广州</font></el-dropdown-item>
						<el-dropdown-item><font size="1">深圳</font></el-dropdown-item>
						<el-dropdown-item><font size="1">南京</font></el-dropdown-item>

					</el-dropdown-menu>
				</el-dropdown>
				<font size="1" color="coral" style="margin-left:8px;">亲，请登录</font>
				<font size="1" style="margin-left:8px;">免费注册</font>
			</el-col>
			<el-col :span="6"></el-col>
			<el-col :span="6" style="text-align: end;">
				<font size="1" style="margin-left:8px;"><i class="el-icon-document"></i> 订单管理</font>
				<font size="1" style="margin-left:8px;"><i class="el-icon-user"></i> 个人中心</font>
			</el-col>
		</el-row>

	</div>

</template>

<script>
</script>

<style>
	  .el-dropdown-link {
    cursor: pointer;
    
  }
  .el-icon-arrow-down {
    font-size: 8px;
  }
</style>
