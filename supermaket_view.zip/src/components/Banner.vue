<template>
	<div>
	<el-row type="flex" class="row-bg" justify="center">
		<el-col :span="4">
			<img height="40px" src="../assets/logo.png" />
		</el-col>
		<el-col :span="8">
			<el-input style="margin-top: 5px;" size="small" placeholder="请输入内容" v-model="input3" class="input-with-select">
				<el-button slot="append" style="width: 30px;"><i style="margin-left: -7px;" class="el-icon-search"></i></el-button>
			</el-input>
		</el-col>
		<el-col :span="6" style="text-align: end;">
			<el-button-group>
				<el-button size="medium" ><font size="1">我的购物车</font></el-button>
				<el-button size="medium" type="danger" icon="el-icon-shopping-cart-2"></el-button>
			</el-button-group>
		</el-col>
	</el-row>
	
	</div>
</template>

<script>
</script>

<style>
</style>
