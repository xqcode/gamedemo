<template>
	<div>
		<el-row type="flex" class="row-bg" justify="center">
			<el-col :span="18">
				<el-cascader-panel  :options="options" style="position:absolute;z-index:100;background:white;height:300px"></el-cascader-panel>
				<div style="margin-left: 182px;z-index:90">
					<el-carousel :interval="5000" arrow="always" >
					<el-carousel-item v-for="item in 4" :key="item" >
						<h3><img src="https://img.alicdn.com/imgextra/i4/126/O1CN01emc7re1CnkRUBilgk_!!126-0-lubanu.jpg_960x960Q75s50.jpg_.webp"></h3>
					</el-carousel-item>
				</el-carousel>
				</div>
				</el-col>
		</el-row>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				options: [{
					value: 'zhinan',
					label: '女装精品',
					children: [{
						value: 'shejiyuanze',
						label: '设计原则',
						children: [{
							value: 'yizhi',
							label: '一致'
						}, {
							value: 'fankui',
							label: '反馈'
						}]
					}, {
						value: 'daohang',
						label: '内衣/男装',
						children: [{
							value: 'cexiangdaohang',
							label: '侧向导航'
						}, {
							value: 'dingbudaohang',
							label: '顶部导航'
						}]
					}]
				}, {
					value: 'zujian',
					label: '鞋品/箱包',
					children: [{
						value: 'basic',
						label: 'Basic',
						children: [{
							value: 'layout',
							label: 'Layout 布局'
						}, {
							value: 'button',
							label: 'Button 按钮'
						}]
					}, {
						value: 'form',
						label: 'Form',
						children: [{
							value: 'radio',
							label: 'Radio 单选框'
						}, {
							value: 'form',
							label: 'Form 表单'
						}]
					}, {
						value: 'data',
						label: 'Data',
						children: [{
							value: 'table',
							label: 'Table 表格'
						}, {
							value: 'tag',
							label: 'Tag 标签'
						}, {
							value: 'progress',
							label: 'Progress 进度条'
						}, {
							value: 'tree',
							label: 'Tree 树形控件'
						}, {
							value: 'pagination',
							label: 'Pagination 分页'
						}, {
							value: 'badge',
							label: 'Badge 标记'
						}]
					}, {
						value: 'notice',
						label: 'Notice',
						children: [{
							value: 'alert',
							label: 'Alert 警告'
						}, {
							value: 'loading',
							label: 'Loading 加载'
						}, {
							value: 'message',
							label: 'Message 消息提示'
						}, {
							value: 'message-box',
							label: 'MessageBox 弹框'
						}, {
							value: 'notification',
							label: 'Notification 通知'
						}]
					}, {
						value: 'navigation',
						label: 'Navigation',
						children: [{
							value: 'menu',
							label: 'NavMenu 导航菜单'
						}, {
							value: 'tabs',
							label: 'Tabs 标签页'
						}, {
							value: 'breadcrumb',
							label: 'Breadcrumb 面包屑'
						}, {
							value: 'dropdown',
							label: 'Dropdown 下拉菜单'
						}, {
							value: 'steps',
							label: 'Steps 步骤条'
						}]
					}, {
						value: 'others',
						label: 'Others',
						children: [{
							value: 'dialog',
							label: 'Dialog 对话框'
						}, {
							value: 'tooltip',
							label: 'Tooltip 文字提示'
						}, {
							value: 'popover',
							label: 'Popover 弹出框'
						}, {
							value: 'card',
							label: 'Card 卡片'
						}, {
							value: 'carousel',
							label: 'Carousel 走马灯'
						}, {
							value: 'collapse',
							label: 'Collapse 折叠面板'
						}]
					}]
				}, {
					value: 'ziyuan',
					label: '内衣/男装',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				},
				{
					value: 'ziyuan',
					label: '饰品/配件',
					children: [{
						value: 'axure',
						label: 'Axure Components'
					}]
				}
				]
			};
		}
	};
</script>

<style>
	
	.el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style>
