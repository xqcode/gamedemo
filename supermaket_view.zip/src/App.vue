<template>
  <div id="app">
<indexhead></indexhead>
<banner style="margin-top: 15px;"></banner>
<indexlist></indexlist>
  </div>
</template>

<script>
	import indexhead from './components/IndexHead.vue'
	import banner from './components/Banner.vue'
	import indexlist from './components/IndexList.vue'
	export default{
		components:{indexhead,banner,indexlist}
	}
</script>

<style>
*{
	margin: 0;
}
</style>
